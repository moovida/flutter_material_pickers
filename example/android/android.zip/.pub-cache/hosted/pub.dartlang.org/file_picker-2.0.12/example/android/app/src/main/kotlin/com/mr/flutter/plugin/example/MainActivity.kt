package com.mr.flutter.plugin.filepicker.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
